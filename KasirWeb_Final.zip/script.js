// =====================
// Util & Storage
// =====================
const $ = (id) => document.getElementById(id);
const fmt = (n) => "Rp" + (n||0).toLocaleString('id-ID');
const todayISO = () => new Date().toISOString().split('T')[0];
const toDMY = (iso) => { const [y,m,d] = iso.split('-'); return `${d}/${m}/${y}`; };

// Seed users (simple)
if(!localStorage.getItem('bsv_users')){
  localStorage.setItem('bsv_users', JSON.stringify([{username:'admin', password:'admin123'}]));
}

// Load or seed barang
let barangList = JSON.parse(localStorage.getItem('bsv_barang')) || [
  { nama:'Kerupuk Basah', hbeli:10000, harga:13000, stok:30 },
];
let keranjang = [];
let laporan = JSON.parse(localStorage.getItem('bsv_laporan')) || []; // list transaksi
let keuangan = JSON.parse(localStorage.getItem('bsv_keuangan')) || []; // list pemasukan/pengeluaran

function saveBarang(){ localStorage.setItem('bsv_barang', JSON.stringify(barangList)); }
function saveLaporan(){ localStorage.setItem('bsv_laporan', JSON.stringify(laporan)); }
function saveKeuangan(){ localStorage.setItem('bsv_keuangan', JSON.stringify(keuangan)); }

// =====================
// Login & Logout
// =====================
function login(){
  const u = document.getElementById('username')?.value?.trim() || '';
  const p = document.getElementById('password')?.value?.trim() || '';
  const users = JSON.parse(localStorage.getItem('bsv_users')) || [];
  const ok = users.find(x=>x.username===u && x.password===p);
  if(ok){
    window.location.href = 'dashboard.html';
  }else{
    const el = document.getElementById('error');
    if(el) el.innerText = '❌ Username atau password salah!';
    else alert('Username atau password salah!');
  }
}
function logout(){ window.location.href = 'index.html'; }

// =====================
// Router (Dashboard)
// =====================
function showPage(page){
  const buttons = document.querySelectorAll('.sidebar button');
  if(buttons) buttons.forEach(b=>b.classList.remove('active'));
  const btn = document.getElementById(`btn-${page}`); if(btn) btn.classList.add('active');
  const c = $('content'); if(!c) return;
  if(page==='transaksi') return renderTransaksi();
  if(page==='stok') return renderStok();
  if(page==='laporan') return renderLaporan();
  if(page==='keuangan') return renderKeuangan();
  c.innerHTML = '<div class="card">Halaman tidak ditemukan.</div>';
}

// =====================
// Transaksi (POS)
// =====================
function renderTransaksi(){
  $('content').innerHTML = `
    <div class="card">
      <h2>🛒 Transaksi Penjualan</h2>
      <div class="input-row">
        <div>
          <label>Barang</label>
          <select id="barangSelect"></select>
        </div>
        <div>
          <label>Qty</label>
          <input id="qty" type="number" min="1" value="1">
        </div>
      </div>
      <div class="input-row">
        <div>
          <label>Tanggal</label>
          <input id="tglTrans" type="date">
        </div>
        <div>
          <label>&nbsp;</label>
          <button class="btn-primary" onclick="tambahKeranjang()">+ Tambah</button>
        </div>
      </div>
      <table>
        <thead><tr><th>Barang</th><th class="center">Qty</th><th class="right">Harga</th><th class="right">Total</th><th></th></tr></thead>
        <tbody id="keranjangTable"></tbody>
        <tfoot><tr><th colspan="3" class="right">Subtotal</th><th id="subtotal" class="right">Rp0</th><th></th></tr></tfoot>
      </table>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button class="btn" onclick="clearKeranjang()">Bersihkan</button>
        <button class="btn-primary" onclick="simpanTransaksi()">Simpan & Cetak Nota</button>
      </div>
      <p class="small">* Stok otomatis berkurang saat barang masuk keranjang.</p>
    </div>
  `;
  const sel = $('barangSelect'); sel.innerHTML='';
  barangList.forEach((b,i)=> sel.innerHTML += `<option value="${i}">${b.nama} — ${fmt(b.harga)} (Stok ${b.stok})</option>`);
  $('tglTrans').value = todayISO();
  renderKeranjang();
}
function tambahKeranjang(){
  const i = parseInt(($('barangSelect')||{}).value||'0');
  const qty = Math.max(1, parseInt(($('qty')||{}).value||'1'));
  const b = barangList[i]; if(!b) return alert('Barang tidak valid');
  if(b.stok < qty) return alert('Stok tidak cukup');
  b.stok -= qty; saveBarang();
  keranjang.push({ nama:b.nama, hbeli:b.hbeli||0, harga:b.harga||0, qty, total:(b.harga||0)*qty });
  renderKeranjang(); renderTransaksiHeaderOnly();
}
function renderTransaksiHeaderOnly(){
  const sel = $('barangSelect'); if(!sel) return;
  sel.innerHTML=''; barangList.forEach((b,i)=> sel.innerHTML += `<option value="${i}">${b.nama} — ${fmt(b.harga)} (Stok ${b.stok})</option>`);
}
function renderKeranjang(){
  const tb = $('keranjangTable'); if(!tb) return;
  tb.innerHTML='';
  let sub=0;
  keranjang.forEach((k,idx)=>{
    sub+=k.total;
    tb.innerHTML += `<tr>
      <td>${k.nama}</td>
      <td class="center">${k.qty}</td>
      <td class="right">${fmt(k.harga)}</td>
      <td class="right">${fmt(k.total)}</td>
      <td class="center"><button class="btn-danger" onclick="hapusItem(${idx})">x</button></td>
    </tr>`;
  });
  const ss = $('subtotal'); if(ss) ss.innerText = fmt(sub);
}
function hapusItem(i){
  const item = keranjang[i];
  const b = barangList.find(x=>x.nama===item.nama);
  if(b) b.stok += item.qty;
  keranjang.splice(i,1); saveBarang(); renderKeranjang(); renderTransaksiHeaderOnly();
}
function clearKeranjang(){
  keranjang.forEach(k=>{ const b = barangList.find(x=>x.nama===k.nama); if(b) b.stok += k.qty; });
  keranjang=[]; renderKeranjang(); renderTransaksiHeaderOnly();
}
function simpanTransaksi(){
  if(!keranjang.length) return alert('Keranjang kosong');
  const iso = $('tglTrans').value || todayISO();
  const tgl = toDMY(iso);
  const jam = new Date().toLocaleTimeString('id-ID');
  const total = keranjang.reduce((a,b)=>a+b.total,0);
  const laba = keranjang.reduce((a,b)=> a + ((b.harga - (b.hbeli||0)) * b.qty), 0);
  laporan.push({ tgl, jam, total, laba, items: keranjang });
  saveLaporan();
  cetakNota(tgl, jam, keranjang, total);
  keranjang = []; renderKeranjang();
  alert('✅ Transaksi disimpan');
}
function cetakNota(tgl, jam, items, total){
  const w = window.open('', 'nota', 'width=380,height=600');
  let rows = items.map(i=>`${i.nama} x${i.qty}  @${fmt(i.harga)} = ${fmt(i.total)}`).join('\n');
  w.document.write(`<pre style="font:14px monospace">PT. BSV Marcela Groups
Nanga Pinoh

Tanggal: ${tgl}  Jam: ${jam}
---------------------------
${rows}
---------------------------
TOTAL: ${fmt(total)}

Terima kasih 🙏</pre>`);
  w.print();
  w.close();
}

// =====================
// Stok
// =====================
function renderStok(){
  $('content').innerHTML = `
    <div class="card">
      <h2>📦 Stok Barang</h2>
      <button class="btn-primary" onclick="formTambahBarang()">+ Tambah Barang</button>
      <table>
        <thead><tr><th>Nama</th><th class="right">Harga Beli</th><th class="right">Harga Jual</th><th class="center">Stok</th><th class="center">Aksi</th></tr></thead>
        <tbody id="stokTable"></tbody>
      </table>
      <p class="small">* Klik Edit untuk ubah harga/stok.</p>
    </div>
  `;
  renderStokTable();
}
function renderStokTable(){
  const tb = $('stokTable'); tb.innerHTML='';
  barangList.forEach((b,i)=>{
    tb.innerHTML += `<tr>
      <td>${b.nama}</td>
      <td class="right">${fmt(b.hbeli||0)}</td>
      <td class="right">${fmt(b.harga||0)}</td>
      <td class="center">${b.stok||0}</td>
      <td class="center">
        <button class="btn" onclick="editBarang(${i})">✏ Edit</button>
        <button class="btn-danger" onclick="hapusBarang(${i})">🗑 Hapus</button>
      </td>
    </tr>`;
  });
}
function formTambahBarang(){
  $('content').innerHTML = `
    <div class="card">
      <h2>➕ Tambah Barang</h2>
      <div class="input-row">
        <input id="nm" placeholder="Nama Barang">
        <input id="hb" type="number" placeholder="Harga Beli">
      </div>
      <div class="input-row">
        <input id="hj" type="number" placeholder="Harga Jual">
        <input id="st" type="number" placeholder="Stok">
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn-primary" onclick="tambahBarangBaru()">Simpan</button>
        <button class="btn" onclick="showPage('stok')">Batal</button>
      </div>
    </div>
  `;
}
function tambahBarangBaru(){
  const nama = $('nm').value.trim();
  const hbeli = parseInt($('hb').value||'0');
  const hjual = parseInt($('hj').value||'0');
  const stok = parseInt($('st').value||'0');
  if(!nama) return alert('Nama wajib');
  barangList.push({ nama, hbeli, harga:hjual, stok });
  saveBarang(); alert('✅ Barang ditambahkan'); showPage('stok');
}
function editBarang(i){
  const b = barangList[i];
  const n = prompt('Nama Barang:', b.nama); if(n===null) return;
  const hb= prompt('Harga Beli:', b.hbeli||0); if(hb===null) return;
  const hj= prompt('Harga Jual:', b.harga||0); if(hj===null) return;
  const st= prompt('Stok:', b.stok||0); if(st===null) return;
  barangList[i] = { nama:n, hbeli:parseInt(hb)||0, harga:parseInt(hj)||0, stok:parseInt(st)||0 };
  saveBarang(); renderStokTable();
}
function hapusBarang(i){
  if(!confirm('Hapus barang ini?')) return;
  barangList.splice(i,1); saveBarang(); renderStokTable();
}

// =====================
// Laporan
// =====================
function renderLaporan(){
  $('content').innerHTML = `
    <div class="card">
      <h2>📈 Laporan Penjualan</h2>
      <div class="input-row">
        <div>
          <label>Filter Tanggal</label>
          <input type="date" id="fltTgl">
        </div>
        <div>
          <label>Filter Bulan</label>
          <input type="month" id="fltBln">
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
        <button class="btn" onclick="renderLaporanTable()">Tampilkan Semua</button>
        <button class="btn-primary" onclick="filterLaporan()">Filter</button>
      </div>
      <div id="lapWrap" style="margin-top:10px"></div>
      <div id="ringkas" class="small"></div>
    </div>
  `;
  renderLaporanTable();
}
function renderLaporanTable(data){
  const list = data || laporan;
  if(!list.length){ $('lapWrap').innerHTML = '<p>Belum ada data.</p>'; $('ringkas').innerText=''; return; }
  const map = {};
  list.forEach(r=>{
    if(!map[r.tgl]) map[r.tgl] = { total:0, laba:0, count:0 };
    map[r.tgl].total += r.total||0;
    map[r.tgl].laba  += r.laba||0;
    map[r.tgl].count += 1;
  });
  const dates = Object.keys(map).sort((a,b)=>{
    const [ad,am,ay]=a.split('/').map(Number);
    const [bd,bm,by]=b.split('/').map(Number);
    return new Date(by,bm-1,bd) - new Date(ay,am-1,ad);
  });
  let html = `<table>
    <thead><tr><th>Tanggal</th><th class="right">Total</th><th class="right">Laba</th><th class="center">Transaksi</th><th class="center">Aksi</th></tr></thead>
    <tbody>`;
  dates.forEach(t=>{
    html += `<tr>
      <td>${t}</td>
      <td class="right">${fmt(map[t].total)}</td>
      <td class="right">${fmt(map[t].laba)}</td>
      <td class="center"><span class="badge">${map[t].count}x</span></td>
      <td class="center"><button class="btn-danger" onclick="hapusLaporanTanggal('${t}')">🗑 Hapus</button></td>
    </tr>`;
  });
  html += `</tbody></table>`;
  $('lapWrap').innerHTML = html;
  const grandTotal = list.reduce((a,b)=>a+(b.total||0),0);
  const grandLaba  = list.reduce((a,b)=>a+(b.laba||0),0);
  $('ringkas').innerHTML = `Total: <b>${fmt(grandTotal)}</b> • Laba: <b>${fmt(grandLaba)}</b>`;
}
function filterLaporan(){
  const t = $('fltTgl').value; const m = $('fltBln').value;
  let data = laporan;
  if(t){ const target = toDMY(t); data = data.filter(x=>x.tgl===target); }
  else if(m){ const [yy,mm] = m.split('-'); data = data.filter(x=>{ const [,M,Y]=x.tgl.split('/'); return Y===yy && M===mm; }); }
  renderLaporanTable(data);
}
function hapusLaporanTanggal(tgl){
  if(!confirm(`Hapus semua transaksi pada ${tgl}?`)) return;
  laporan = laporan.filter(x=>x.tgl!==tgl); saveLaporan(); renderLaporanTable();
}

// =====================
// Keuangan
// =====================
function renderKeuangan(){
  $('content').innerHTML = `
    <div class="card">
      <h2>💸 Pemasukan & Pengeluaran</h2>
      <div class="input-row">
        <input type="date" id="k_tgl">
        <select id="k_jenis">
          <option value="pemasukan">Pemasukan</option>
          <option value="pengeluaran">Pengeluaran</option>
        </select>
      </div>
      <div class="input-row">
        <input id="k_ket" placeholder="Keterangan (misal: Penjualan / Beli Solar)">
        <input id="k_nom" type="number" placeholder="Nominal">
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn-primary" onclick="keuTambah()">Tambah</button>
        <button class="btn" onclick="keuTampil()">Tampilkan Semua</button>
      </div>

      <div class="input-row" style="margin-top:12px">
        <input type="date" id="kf_tgl">
        <input type="month" id="kf_bln">
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" onclick="keuTampil()">Reset</button>
        <button class="btn-primary" onclick="keuFilter()">Filter</button>
      </div>

      <div id="keuWrap" style="margin-top:10px"></div>
      <div id="keuRingkas" class="small"></div>
    </div>
  `;
  $('k_tgl').value = todayISO();
  keuTampil();
}
function keuTambah(){
  const iso = $('k_tgl').value || todayISO();
  const tgl = toDMY(iso);
  const jenis = $('k_jenis').value;
  const ket = $('k_ket').value.trim() || jenis;
  const nom = parseInt($('k_nom').value||'0');
  if(!nom) return alert('Nominal kosong');
  keuangan.push({ id:Date.now(), tgl, jenis, ket, nominal:nom });
  saveKeuangan(); $('k_ket').value=''; $('k_nom').value=''; keuTampil();
}
function keuTampil(data){
  const list = data || keuangan;
  if(!list.length){ $('keuWrap').innerHTML='<p>Belum ada data.</p>'; $('keuRingkas').innerText=''; return; }
  let masuk=0, keluar=0, rows='';
  list.forEach(e=>{
    if(e.jenis==='pemasukan') masuk+=e.nominal; else keluar+=e.nominal;
    rows += `<tr>
      <td>${e.tgl}</td><td>${e.ket}</td><td>${e.jenis}</td>
      <td class="right">${fmt(e.nominal)}</td>
      <td class="center">
        <button class="btn" onclick="keuEdit(${e.id})">✏</button>
        <button class="btn-danger" onclick="keuHapus(${e.id})">🗑</button>
      </td>
    </tr>`;
  });
  $('keuWrap').innerHTML = `<table>
    <thead><tr><th>Tgl</th><th>Keterangan</th><th>Jenis</th><th class="right">Nominal</th><th class="center">Aksi</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
  $('keuRingkas').innerHTML = `Masuk: <b>${fmt(masuk)}</b> • Keluar: <b>${fmt(keluar)}</b> • Saldo: <b>${fmt(masuk-keluar)}</b>`;
}
function keuFilter(){
  const t = $('kf_tgl').value; const m = $('kf_bln').value;
  let data = keuangan;
  if(t){ const T = toDMY(t); data = data.filter(x=>x.tgl===T); }
  else if(m){ const [yy,mm]=m.split('-'); data = data.filter(x=>{ const [,M,Y]=x.tgl.split('/'); return Y===yy && M===mm; }); }
  keuTampil(data);
}
function keuEdit(id){
  const e = keuangan.find(x=>x.id===id); if(!e) return;
  const t = prompt('Tanggal (dd/mm/yyyy):', e.tgl); if(t===null) return;
  const k = prompt('Keterangan:', e.ket); if(k===null) return;
  const j = prompt('Jenis (pemasukan/pengeluaran):', e.jenis); if(j===null) return;
  const n = parseInt(prompt('Nominal:', e.nominal)); if(isNaN(n)) return;
  Object.assign(e,{tgl:t, ket:k, jenis:j, nominal:n}); saveKeuangan(); keuTampil();
}
function keuHapus(id){
  if(!confirm('Hapus data ini?')) return;
  keuangan = keuangan.filter(x=>x.id!==id); saveKeuangan(); keuTampil();
}
